<?php
class Admin_model extends CI_Model{
		var $table;
	public function  __construct(){
		parent::__construct();
		$this->load->database();
	}


/*
	| -------------------------------------------------------------------
	| check unique fields
	| -------------------------------------------------------------------
	|
	*/
	public function isUnique($table, $field, $value,$id='')
	{
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where($field,$value);
		if($id!='')
		{
			$this->db->where("id != ",$id);
		}
		$query = $this->db->get();
		$data = $query->num_rows();
		return ($data > 0)?FALSE:TRUE;
	}

		/*
	| -------------------------------------------------------------------
	| Insert data
	| -------------------------------------------------------------------
	|
	| general function to insert data in table
	|
	*/
	public function insertData($table, $data)
	{
		
		$result = $this->db->insert($table, $data);
		if($result == 1){
			return $this->db->insert_id();
		}else{
			return false;
		}
	}

	public function insertData_batch($table, $data)
	{
		
		$this->db->insert_batch($table, $data);
		return true;
	}
	/*
	| -------------------------------------------------------------------
	| Update data
	| -------------------------------------------------------------------
	|
	| general function to update data
	|
	*/
	public function updateData($table, $data, $where)
	{
		$this->db->where($where);
		$this->db->update($table, $data);
		return $this->db->affected_rows();
	}
	
	
	/*
	| -------------------------------------------------------------------
	| Select data
	| -------------------------------------------------------------------
	|
	| general function to get result by passing nesessary parameters
	|
	*/
	public function selectData($table, $fields='*', $where='', $order_by="", $order_type="", $group_by="", $limit="", $rows="", $type='')
	{
		$this->db->select($fields);
		$this->db->from($table);
		if ($where != "") {
			$this->db->where($where);
		}

		if ($order_by != '') {
			$this->db->order_by($order_by,$order_type);
		}

		if ($group_by != '') {
			$this->db->group_by($group_by);
		}

		if ($limit > 0 && $rows == "") {
			$this->db->limit($limit);
		}
		if ($rows > 0) {
			$this->db->limit($rows, $limit);
		}


		$query = $this->db->get();

		if ($type == "rowcount") {
			$data = $query->num_rows();
		}else{
			$data = $query->result();
		}

		$query->result();

		return $data;
	}

	
	
		/*
	| -------------------------------------------------------------------
	| Delere data
	| -------------------------------------------------------------------
	|
	| general function to delete the records
	|
	*/
	public function deleteData($table, $data)
	{
		if($this->db->delete($table, $data)){
			return 1;
		}else{
			return 0;
		}
	}
	public function fetchCategories($Data,$sort_field,$orderBy,$c)
	{
		
		$this->db->select("*");
		
		$this->db->from('categories');
		if(!empty($Data['search']['value']))
		{
			
			$this->db->group_start();
			$this->db->where("cat_id like ","%".$Data['search']['value']."%");
			$this->db->or_where("cat_title like ","%".$Data['search']['value']."%");
			$this->db->or_where("status like ","%".$Data['search']['value']."%");
			$this->db->or_where("created_at like ","%".date('Y-m-d',strtotime(str_replace('/', '-',$Data['search']['value'])))."%");
			$this->db->group_end();
						
		}
		
		
		$this->db->order_by("".$sort_field." ".$orderBy."");
		
		if( $c == 1)
		{
			if($Data['length']!= -1){		
			$this->db->limit($Data['length'],$Data['start']);
			}
			$query = $this->db->get();
			//echo $this->db->last_query(); exit;
			$result= $query->result_array();
			
			return $result;			
		}
		else
		{		
			
			$query = $this->db->get();
			$result['NumRecords']=$query->num_rows();		
			return $result;		
		}

	}
	public function fetchProducts($Data,$sort_field,$orderBy,$c)
	{
		
		$this->db->select("p.*");
		
		$this->db->from('products as p');
		if(!empty($Data['search']['value']))
		{
			
			$this->db->group_start();
			$this->db->where("p.product_id like ","%".$Data['search']['value']."%");
			$this->db->or_where("p.product_title like ","%".$Data['search']['value']."%");
			$this->db->or_where("p.status like ","%".$Data['search']['value']."%");
			$this->db->or_where("p.created_at like ","%".date('Y-m-d',strtotime(str_replace('/', '-',$Data['search']['value'])))."%");
			$this->db->group_end();
						
		}
		
		$this->db->order_by("".$sort_field." ".$orderBy."");
		
		if( $c == 1)
		{
			if($Data['length']!= -1){		
			$this->db->limit($Data['length'],$Data['start']);
			}
			$query = $this->db->get();
			//echo $this->db->last_query(); exit;
			$result= $query->result_array();
			
			return $result;			
		}
		else
		{		
			
			$query = $this->db->get();
			$result['NumRecords']=$query->num_rows();		
			return $result;		
		}

	}
	public function getCategories($arr)
	{
		$this->db->select("cat_title");
		$this->db->from('categories');
		$this->db->where_in("cat_id",$arr);
		$query = $this->db->get();
		return $query->result_array();
	}
	function upload_files($input = "", $folder="default" ,$index="", $allowd="",$prefix="")
    {
        $this->load->library('upload');
        $structure = DOC_ROOT_UPLOAD_PATH;
        $folders = explode("/", $folder);

        foreach($folders as $dir)
        {
            if($dir != "")
            {
                if (!file_exists($structure.$dir)) 
                {
                    mkdir($structure.$dir, 0777, true);
                    chmod($structure.$dir, 0777);
                }
                else
                {
                    chmod($structure.$dir, 0777);
                }
                $structure .= $dir."/";
                $folder = $dir;
            }
        }

        $config['upload_path']    = $structure;
        $config['allowed_types']  = $allowd;
        $file_ext = pathinfo($_FILES[$input]["name"],PATHINFO_EXTENSION);
        $config['file_name']  = str_replace('.'.$file_ext,'',$_FILES[$input]["name"]);
        $this->upload->initialize($config);
        if($this->upload->do_upload($input))
        {
            $data = $this->upload->data();
            return $data;
        }
        else
        {
            $error = $this->upload->display_errors();
           // print_r($error); 
            return $error;
        }
        return false;
    }
    public function getProduct($p_slug) 
	{
		$this->db->select('p.*,i.image_name');
		$this->db->from('products as p');
		$this->db->join('product_images as i', 'i.prod_id=p.product_id', 'left');
		$this->db->where('p.p_slug', $p_slug);
		$query = $this->db->get();
		return $query->result();
	}
	public function fetchUsers($Data,$sort_field,$orderBy,$c)
	{
		
		$this->db->select("*");
		
		$this->db->from('users');
		if(!empty($Data['search']['value']))
		{
			
			$this->db->group_start();
			$this->db->where("id like ","%".$Data['search']['value']."%");
			$this->db->or_where("name like ","%".$Data['search']['value']."%");
			$this->db->or_where("email like ","%".$Data['search']['value']."%");
			$this->db->or_where("phone like ","%".$Data['search']['value']."%");
			$this->db->or_where("status like ","%".$Data['search']['value']."%");
			$this->db->or_where("created_at like ","%".date('Y-m-d',strtotime(str_replace('/', '-',$Data['search']['value'])))."%");
			$this->db->group_end();
						
		}
		
		$this->db->order_by("".$sort_field." ".$orderBy."");
		
		if( $c == 1)
		{
			if($Data['length']!= -1){		
			$this->db->limit($Data['length'],$Data['start']);
			}
			$query = $this->db->get();
			//echo $this->db->last_query(); exit;
			$result= $query->result_array();
			
			return $result;			
		}
		else
		{		
			
			$query = $this->db->get();
			$result['NumRecords']=$query->num_rows();		
			return $result;		
		}

	}

}
?>
