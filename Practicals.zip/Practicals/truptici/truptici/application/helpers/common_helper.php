<?php 
    
    function public_path($type="www")
    {
        return base_url()."assets/";
    }

    function base_path($type="www")
    {
      return base_url();
    }
     /*admin base url path */
    function admin_path($type="www")
    {
      return base_url();
    }
    function upload_path($type="www")
    {
        return base_url()."assets/uploads/";
    }
     function get_active_tab_main($tab)
    {
      $CI =& get_instance();
        if ($CI->router->fetch_method() == $tab) {
            return 'active';
        }

    }

    function translate($text)
    {
      $CI =& get_instance();
      $line=$CI->lang->line($text);
      if(empty($line))
      {
        $line=$text;
      }
      
      return $line;
    }
    
    function is_admin_login()
    {
      $CI =& get_instance();
      $session = $CI->session->userdata('admin_session');
      if (!isset($session['admin_id'])) {
        redirect(base_url().'the-triangles-admin');
      }
    }


    function duplicateSlugeVerify($slug,$table,$field='vslug'){
      if($table!=''){
        $CI =& get_instance();

        $CI->load->model('Admin_model');
        $slugData = $CI->Admin_model->selectData($table,'',array($field => $slug),'','','','','','rowcount');
        if($slugData>0){
          $slug = $slug.'-'.time();
        }
        return $slug;
      }
    }
    

    function getValidUrl($url){
      if (!preg_match("~^(?:f|ht)tps?://~i", $url) && $url!='') {
       $url = "http://" . $url;
       return $url;
      }
      else
      {
        return $url;
      }
    }

    function last_query()
    {
      $CI =& get_instance();
      echo "<pre>";
      print_r($CI->db->last_query());
      exit();
    }

  



?>