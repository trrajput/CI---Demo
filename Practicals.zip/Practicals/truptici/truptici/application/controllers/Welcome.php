<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
		$this->admin_session = $this->session->userdata('admin_session');
		$this->load->model('Admin_model');
		$this->load->library('user_agent');
		$this->ip_address=$this->input->ip_address();
		//$this->load->model('User_model');
	}
	public function index()
	{
		
		/*$this->load->library('user_agent');
		if ($this->agent->is_referral())
		{
		    echo $this->agent->referrer();
		}*/
		$post = $this->input->post();

		if ($post) {

			$this->form_validation->set_data($post);
			$this->form_validation->set_rules('email', 'Email Address',  'trim|required|valid_email');
			$this->form_validation->set_rules('password', 'Password', 'required');
			if ($this->form_validation->run() == FALSE)

			{ }else{
				
				$post['status']='Active';
				$post['password']=md5($post['password']);
				$user = $this->Admin_model->selectData('admin','*', $post);
				if (count($user) > 0) {	
					
					$this->session->unset_userdata('admin_session');			
					# create session
					$session = array(
						'admin_id' => $user[0]->admin_id,
						'admin_name' => $user[0]->full_name,
						'admin_email' => $user[0]->email,
					);
					$this->session->set_userdata('admin_session',$session);
					redirect('dashboard');
				}else{
					$this->session->set_flashdata('error',"Invalid email address or password");
				}
				//redirect('login');	
			}
		}
		$this->load->view('login');
	
	}
	public function dashboard()
	{
		is_admin_login();
		$data= array();
		
		$this->load->view('users',$data);

	}
	/*--- Category ---*/
	public function categories(){
	
		$data['category'] = $this->Admin_model->selectData('categories','*',array('status'=>'Active'),'cat_id','DESC');
		
		$this->load->view('categories',$data);
	}
	public function get_categories()
	{
		$post = $this->input->post();
		
		$field_pos=array("cat_id"=>'0',"cat_title"=>'1',"created_at"=>'2',"status"=>'3');
		
		$sort_field=array_search($post['order'][0]['column'],$field_pos);

		if($post['order'][0]['dir']=='asc')
		{
	 		$orderBy="ASC";
		}
	 	else
		{
	 		$orderBy="DESC";
		}	
		
		$TotalRecord=$this->Admin_model->fetchCategories($post,$sort_field,$orderBy,0);	
	 	$userData = $this->Admin_model->fetchCategories($post,$sort_field,$orderBy,1);

	 	$iTotalRecords = $TotalRecord['NumRecords'];

	 	$records = array();
	  	$records["data"] = array();
		
	  	foreach ($userData as $key => $value) {
	  		
				
			$name='<span class="font-bold">'.$value['cat_title'].'</span>';
			
			
			$createdat='';
			if($value['created_at']!='')
			{
				
				$dateTime = date("d-m-Y",  strtotime($value['created_at']));
				if($value['created_at']=='0000-00-00'){
					$dateTime='';
				}
				$createdat = str_replace("-","/",$dateTime);
			}
			
	  		$action = '';$status='';
	  		if($value['status']=="Active"){
	  		$status="<button class='fcbtn btn btn-success btn-outline btn-1d' onclick='changeStatus(".$value['cat_id'].",\"".$value['status']."\",\"categories\",\"cat_id\");'>".$value['status']."</button>";	
	  		}else{
	  		$status="<button class='fcbtn btn btn-danger btn-outline btn-1d' onclick='changeStatus(".$value['cat_id'].",\"".$value['status']."\",\"categories\",\"cat_id\");' >Inactive</button>";
	  		}
	  		
	  		$action="<div class='bulk-action'>
	  		<a href='".base_url().'welcome/edit-category/'.$value['cat_slug']."'><i class='far fa-edit' title='edit'></i></a><a href='javascript:void(0)'  onclick='delete_record(".$value['cat_id'].",\"categories\",\"cat_id\");'><i class='far fa-trash-alt' title='delete'></i></a></div>";

	  			
	  			$records["data"][] = array(
				$value['cat_id'],
				$name,
	  			$createdat,
	  			$status,
	  			$action,
	  			
	  			);
	  		
	  	}

	  	$records["draw"] = intval($post['draw']);
		$records["recordsTotal"] = $iTotalRecords;
		$records["recordsFiltered"] = $iTotalRecords;		
		echo json_encode($records);				  
		exit;
	}
	function add_category(){
		$post = $this->input->post();
		if($post){
			$slug = url_title($post['cat_title'], 'dash', true);
    		$post['cat_slug'] =	duplicateSlugeVerify($slug,'categories','cat_slug');
			$flag = $this->Admin_model->insertData('categories', $post);
			if($flag != false)
			{
				
				$this->session->set_userdata('success','Successfully created');
			}
			else{
					$this->session->set_userdata('error','Error while processing!!');
					
			}
			redirect('welcome/categories');
		}
		
		$this->load->view('add_category');
	}

	function edit_category($cat_slug){

		if($cat_slug==''){
			redirect('welcome/categories');
		}
		$post = $this->input->post();
		if($post){

			$flag = $this->Admin_model->updateData('categories', $post,array('cat_slug'=>$cat_slug));
			if($flag != false)
			{
				
				$this->session->set_userdata('success','Successfully updated');
			}
			else{
				$this->session->set_userdata('error','Error while processing!!');
					
			}
			redirect('welcome/categories');
		}
		$data['category']	=	$this->Admin_model->selectData('categories', '*',array('cat_slug'=>$cat_slug),'cat_title','ASC');
		if(count($data['category'])==0){
			
			redirect('welcome/categories');
		}

		$this->load->view('add_category',$data);

	}
	public function products(){
	
		$data['product'] = $this->Admin_model->selectData('products','*',array('status'=>'Active'),'product_id','DESC');
		
		$this->load->view('products',$data);
	}
	public function get_products()
	{
		$post = $this->input->post();
		
		$field_pos=array("product_id"=>'0',"product_title"=>'1',"created_at"=>'3',"status"=>'4');
		
		$sort_field=array_search($post['order'][0]['column'],$field_pos);

		if($post['order'][0]['dir']=='asc')
		{
	 		$orderBy="ASC";
		}
	 	else
		{
	 		$orderBy="DESC";
		}	
		
		$TotalRecord=$this->Admin_model->fetchProducts($post,$sort_field,$orderBy,0);	
	 	$userData = $this->Admin_model->fetchProducts($post,$sort_field,$orderBy,1);

	 	$iTotalRecords = $TotalRecord['NumRecords'];

	 	$records = array();
	  	$records["data"] = array();
		
	  	foreach ($userData as $key => $value) {
				
			$name='<span class="font-bold">'.$value['product_title'].'</span>';
			
			$createdat='';
			if($value['created_at']!='')
			{
				
				$dateTime = date("d-m-Y",  strtotime($value['created_at']));
				if($value['created_at']=='0000-00-00'){
					$dateTime='';
				}
				$createdat = str_replace("-","/",$dateTime);
			}
			$getcat=explode('|*|',$value["categories"]);
			$getcat=$this->Admin_model->getCategories($getcat);	
			$categories=implode(', ', array_map(function ($entry) {
			  return $entry['cat_title'];
			}, $getcat));
	  		$action = '';$status='';
	  		if($value['status']=="Active"){
	  		$status="<button class='fcbtn btn btn-success btn-outline btn-1d' onclick='changeStatus(".$value['product_id'].",\"".$value['status']."\",\"products\",\"product_id\");'>".$value['status']."</button>";	
	  		}else{
	  		$status="<button class='fcbtn btn btn-danger btn-outline btn-1d' onclick='changeStatus(".$value['product_id'].",\"".$value['status']."\",\"products\",\"product_id\");' >Inactive</button>";
	  		}
	  		
	  		$action="<div class='bulk-action'>
	  		<a href='".base_url().'welcome/view-product/'.$value['p_slug']."'><i class='far fa-eye' title='view'></i></a><a href='".base_url().'welcome/edit-product/'.$value['p_slug']."'><i class='far fa-edit' title='edit'></i></a><a href='javascript:void(0)'  onclick='delete_record(".$value['product_id'].",\"products\",\"product_id\");'><i class='far fa-trash-alt' title='delete'></i></a></div>";

	  			
	  			$records["data"][] = array(
				$value['product_id'],
				$name,
				$categories,
	  			$createdat,
	  			$status,
	  			$action,
	  			
	  			);
	  		
	  	}

	  	$records["draw"] = intval($post['draw']);
		$records["recordsTotal"] = $iTotalRecords;
		$records["recordsFiltered"] = $iTotalRecords;		
		echo json_encode($records);				  
		exit;
	}
	function add_product(){
		$post = $this->input->post();
		$image_info = $_FILES;
		if($post){
			unset($post['files']);
			$post['categories']=implode('|*|',$post['categories']);
			$slug = url_title($post['product_title'], 'dash', true);
    		$post['p_slug'] =	duplicateSlugeVerify($slug,'products','p_slug');


			$flag = $this->Admin_model->insertData('products', $post);
			if($flag != false)
			{
				if ($image_info['gallary_img'] != '' || $image_info['gallary_img'] != NULL && $image_info['featured_img'] != '' || $image_info['featured_img'] != NULL) 
						{
							if(!empty(@$_FILES['featured_img']['name'])){	
								
							  $_FILES['featured_img']['name']      = $image_info['featured_img']['name'];
							  $_FILES['featured_img']['type']      = $image_info['featured_img']['type'];
							  $_FILES['featured_img']['tmp_name']  = $image_info['featured_img']['tmp_name'];
							  $_FILES['featured_img']['error']     = $image_info['featured_img']['error'];
							  $_FILES['featured_img']['size']      = $image_info['featured_img']['size'];

								$featured_img=$this->Admin_model->upload_files('featured_img','featured_image/'.$flag,'',$allowd="jpg|jpeg|png");
								$error = $this->upload->display_errors();
           
					           	if(!$featured_img){
					           		$this->session->set_flashdata('error',$error);
					           		redirect('welcome/products');
					           	}
								$data['featured_image']	= $featured_img['file_name'];
				           		$update =$this->Admin_model->updateData('products',$data,array('product_id' =>$flag));
				           	}	
						$files = @$_FILES['gallary_img'];
						for($i=0;$i<count($files['name']);$i++)
						{
						 	if(!empty(@$_FILES['gallary_img']['name'][$i]))
					      	{	
							  $_FILES['gallary_img']['name']      = $files['name'][$i];
							  $_FILES['gallary_img']['type']      = $files['type'][$i];
							  $_FILES['gallary_img']['tmp_name']  = $files['tmp_name'][$i];
							  $_FILES['gallary_img']['error']     = $files['error'][$i];
							  $_FILES['gallary_img']['size']      = $files['size'][$i];
							  $gallary_imgs=$this->Admin_model->upload_files('gallary_img','gallary/'.$flag,'',$allowd="jpg|jpeg|png");
					          	if(!$gallary_imgs){
					          		$error = $this->upload->display_errors();
	       			           		$this->session->set_flashdata('error',$error);
	       			           		redirect('welcome/products');
	           						 
				               	}	
	           					$insertImages =$this->Admin_model->insertData('product_images',array('prod_id'=>$flag,'image_name'=>$gallary_imgs['file_name'],'image_size'=>$gallary_imgs['file_size']));
				            		
				               	}	
		           			}	
		           		}
				      
				$this->session->set_userdata('success','Successfully created');
			}
			else{
					$this->session->set_userdata('error','Error while processing!!');
					
			}
			redirect('welcome/products');
		}
		$data['categories']	=	$this->Admin_model->selectData('categories', '*',array('status'=>'Active'),'cat_title','ASC');
		
		$this->load->view('add_product',$data);
	}

	function edit_product($p_slug){

		if($p_slug==''){
			redirect('welcome/products');
		}
		$post = $this->input->post();
		$image_info = $_FILES;
		if($post){
			unset($post['files']);
			$post['categories']=implode('|*|',$post['categories']);
			$flag = $this->Admin_model->updateData('products', $post,array('p_slug'=>$p_slug));
			$prod = $this->Admin_model->selectData('products','product_id',array('p_slug'=>$p_slug));
			if ($image_info['gallary_img'] != '' || $image_info['gallary_img'] != NULL && $image_info['featured_img'] != '' || $image_info['featured_img'] != NULL) 
				{
					if(!empty(@$_FILES['featured_img']['name'])){
					//print_r(@$_FILES['featured_img']['name']);exit;	
					  $_FILES['featured_img']['name']      = $image_info['featured_img']['name'];
					  $_FILES['featured_img']['type']      = $image_info['featured_img']['type'];
					  $_FILES['featured_img']['tmp_name']  = $image_info['featured_img']['tmp_name'];
					  $_FILES['featured_img']['error']     = $image_info['featured_img']['error'];
					  $_FILES['featured_img']['size']      = $image_info['featured_img']['size'];

						$featured_img=$this->Admin_model->upload_files('featured_img','featured_image/'.$prod[0]->product_id,'',$allowd="jpg|jpeg|png");
						$error = $this->upload->display_errors();
           
			           	if(!$featured_img){
			           		$this->session->set_flashdata('error',$error);
			           		redirect('welcome/products');
			           	}
						$data['featured_image']	= $featured_img['file_name'];
		           		$update =$this->Admin_model->updateData('products',$data,array('product_id' =>$prod[0]->product_id));
			           $this->session->set_userdata('success','Successfully image updated');
			          }
			          $count=0;
						$files = @$_FILES['gallary_img'];
						for($i=0;$i<count($files['name']);$i++)
						{
						 	if(!empty(@$_FILES['gallary_img']['name'][$i]))
					      	{	
					      		$count=$count+1;
					      		if($count==1){
					      			 $delete =$this->Admin_model->deleteData('product_images',array('prod_id'=>$prod[0]->product_id));
					      		}
							  $_FILES['gallary_img']['name']      = $files['name'][$i];
							  $_FILES['gallary_img']['type']      = $files['type'][$i];
							  $_FILES['gallary_img']['tmp_name']  = $files['tmp_name'][$i];
							  $_FILES['gallary_img']['error']     = $files['error'][$i];
							  $_FILES['gallary_img']['size']      = $files['size'][$i];
							  $gallary_imgs=$this->Admin_model->upload_files('gallary_img','gallary/'.$prod[0]->product_id,'',$allowd="jpg|jpeg|png");
					          	if(!$gallary_imgs){
					          		$error = $this->upload->display_errors();
           			           		$this->session->set_flashdata('error',$error);
           			           		redirect('welcome/products');
               						 
				               	}	
				               	$insertImages =$this->Admin_model->insertData('product_images',array('prod_id'=>$prod[0]->product_id,'image_name'=>$gallary_imgs['file_name'],'image_size'=>$gallary_imgs['file_size']));
				            	$this->session->set_userdata('success','Successfully image updated');
		           			}	
		           		}
		           		
		        }
			if($flag != false)
			{

				$this->session->set_userdata('success','Successfully updated');
			}
			else{
				$this->session->set_userdata('error','Error while processing!!');
					
			}
			redirect('welcome/products');
		}
		$data['categories']	=	$this->Admin_model->selectData('categories', '*',array('status'=>'Active'),'cat_title','ASC');
		$data['info']	=	$this->Admin_model->selectData('products', '*',array('p_slug'=>$p_slug),'product_title','ASC');
		$data['gallary']	=	$this->Admin_model->selectData('product_images', '*',array('prod_id'=>$data['info'][0]->product_id));
		
		if(count($data['info'])==0){
			
			redirect('welcome/products');
		}

		$this->load->view('add_product',$data);

	}
	public function view_product($p_slug)
	{
		if (!empty($p_slug)) 
		{	
			$data['info'] = $this->Admin_model->getProduct($p_slug);
			//print_r($data['info']);exit;
			/*if (count($data['info'])) {
				redirect('welcome/products');
			}*/
			$getcat=explode('|*|',$data['info'][0]->categories);
			$getcat=$this->Admin_model->getCategories($getcat);	
			$data['cat']=implode(', ', array_map(function ($entry) {
			  return $entry['cat_title'];
			}, $getcat));

			$this->load->view('product_details',$data);
		}else {
			redirect('welcome/products');
		}
		
	}
	public function change_status()
	{
		$post = $this->input->post();

		if(!empty($post['app_id']) && !empty($post['status']) && !empty($post['table']) && !empty($post['table_id']))
		{
			$newStatus = ($post['status'] == 'Active')? 'Inactive' : 'Active';
						 

			$this->Admin_model->updateData($post['table'],array('status' => $newStatus), array($post['table_id'] => $post['app_id']));
			echo "success";					

		}
		else
		{
			echo "Error";
		}
		exit;
	}
	public function delete_record()
	{
		$post = $this->input->post();

		if(!empty($post['app_id']) && !empty($post['table']) && !empty($post['table_id']))
		{
				 

			$this->Admin_model->deleteData($post['table'], array($post['table_id'] => $post['app_id']));
			echo "success";					

		}
		else
		{
			echo "Error";
		}
		exit;
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_path());
	}
	public function users(){
	
		$data['category'] = $this->Admin_model->selectData('users','*',array('status'=>'Active'),'id','DESC');
		$this->load->view('categories',$data);
	}
	public function get_users()
	{
		$post = $this->input->post();
		
		$field_pos=array("id"=>'0',"name"=>'1',"email"=>'2',"phone"=>'3',"created_at"=>'4',"status"=>'5');
		
		$sort_field=array_search($post['order'][0]['column'],$field_pos);

		if($post['order'][0]['dir']=='asc')
		{
	 		$orderBy="ASC";
		}
	 	else
		{
	 		$orderBy="DESC";
		}	
		
		$TotalRecord=$this->Admin_model->fetchUsers($post,$sort_field,$orderBy,0);	
	 	$userData = $this->Admin_model->fetchUsers($post,$sort_field,$orderBy,1);

	 	$iTotalRecords = $TotalRecord['NumRecords'];

	 	$records = array();
	  	$records["data"] = array();
		
	  	foreach ($userData as $key => $value) {
				
			$name='<span class="font-bold">'.$value['name'].'</span>';
			
			$createdat='';
			if($value['created_at']!='')
			{
				
				$dateTime = date("d-m-Y",  strtotime($value['created_at']));
				if($value['created_at']=='0000-00-00'){
					$dateTime='';
				}
				$createdat = str_replace("-","/",$dateTime);
			}
			
	  		$action = '';$status='';
	  		if($value['status']=="Active"){
	  		$status="<button class='fcbtn btn btn-success btn-outline btn-1d' onclick='changeStatus(".$value['id'].",\"".$value['status']."\",\"users\",\"id\");'>".$value['status']."</button>";	
	  		}else{
	  		$status="<button class='fcbtn btn btn-danger btn-outline btn-1d' onclick='changeStatus(".$value['id'].",\"".$value['status']."\",\"users\",\"id\");' >Inactive</button>";
	  		}
	  		
	  		$action="<div class='bulk-action'>
	  		</div>";

	  			
	  			$records["data"][] = array(
				$value['id'],
				$name,
				$value['email'],
				$value['phone'],
	  			$createdat,
	  			$status,
	  			$action,
	  			
	  			);
	  		
	  	}

	  	$records["draw"] = intval($post['draw']);
		$records["recordsTotal"] = $iTotalRecords;
		$records["recordsFiltered"] = $iTotalRecords;		
		echo json_encode($records);				  
		exit;
	}
}
