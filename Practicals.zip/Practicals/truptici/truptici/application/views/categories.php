<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Categories List</title>
 
<?php $this->load->view('template/header'); ?>  
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/plugins/datatables-bs4/css/dataTables.bootstrap4.css">
<?php $this->load->view('template/sidebar'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header py-1">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <ol class="breadcrumb">
              <li class="breadcrumb-item active">Categories List</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div id="flash_msg" class="">
          </div> 
          <div class="card card-warning card-outline">
            <div class="card-header">
              <h3 class="card-title mt-1">Categories List</h3>
               <div class="float-right">
               
                  <a href="<?= base_url(); ?>welcome/add_category" class="btn btn-outline-success btn-sm">NEW CATEGORY</a>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body text-sm">
              <table id="categories" class="table table-bordered table-striped table-hover" style="width: 100%;">
                <thead>
                <tr>
                  <th>Id</th>
                  <th>Title</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody></tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
  </div>
<?php $this->load->view('template/footer'); ?>

<script src="<?= base_url(); ?>assets/admin/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?= base_url(); ?>assets/admin/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>


<script>
$(document).ready(function() {
    ajaxDataTableInit(base_path+'welcome/get_categories','categories');
  
});
function ajaxDataTableInit(url,id,order=0,number=-1)
{  
    oTable = $('#'+id).dataTable( {

        "processing": true,
        "serverSide": true,
          
        "order": [[order, "desc" ]],
        "pageLength": 50,
        "scrollX": true,
        "ajax": {
            url: url,
            type: "POST",
        },
        "fnDrawCallback": function () {
           
        },

        aoColumnDefs: [
          {
             bSortable: false,
             aTargets:number

          },
           
        ], 

    } );
}
function changeStatus(app_id , status,table,table_id)
{
  
   // startLoading();
    $.ajax({
        type: 'post',
        data:{app_id : app_id , status : status,table : table,table_id : table_id},
        url: base_path+'welcome/change_status',
        success: function (data) {
            if($.trim(data) == 'success')
            {
               
                $('table').DataTable().ajax.reload(null, false);
            }
            else
            {
                $('#flash_msg').html(error_msg_box("Something wrong, Please try again."));
            }
            $('table').DataTable().ajax.reload(null, false);
             //stopLoading();
        },
        complete: function(){
            //stopLoading();
        }
    });

}
function delete_record(app_id ,table,table_id)
{
  
   // startLoading();
   if (confirm("Are you sure want to delete this reload?")) {
    $.ajax({
        type: 'post',
        data:{app_id : app_id ,table : table,table_id : table_id},
        url: base_path+'welcome/delete_record',
        success: function (data) {
            if($.trim(data) == 'success')
            {
               
                $('table').DataTable().ajax.reload(null, false);
            }
            else
            {
                $('#flash_msg').html(error_msg_box("Something wrong, Please try again."));
            }
            $('table').DataTable().ajax.reload(null, false);
             //stopLoading();
        },
        complete: function(){
            //stopLoading();
        }
    });
  }
}
</script>

</body>
</html>
