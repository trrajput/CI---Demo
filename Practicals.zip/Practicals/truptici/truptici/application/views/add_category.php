<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>New Session</title>
  
<?php $this->load->view('template/header'); ?>  

<?php $this->load->view('template/sidebar'); ?>

<style type="text/css">
.help-block.text-danger {
    font-size: 14px;
}
</style>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header py-1">
      <div class="container-fluid">
        <div class="row mb-2">
          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- Left col -->
           <section class="col-md-6 offset-3">
             <div class="card card-warning card-outline">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="fas fa-plus-circle mr-1 text-olive"></i>
                  New Category
                </h3>
              </div>
              <!-- /.card-header -->
            <form role="form" method="post" action="" id="cat-frm" name="cat-frm" >
                  <div class="card-body">
                     <div class="row">
                        <div class="col-md-8">
                          <div class="form-group">
                            <label>Category Title <span class="text-maroon">*</span></label>
                            <input type="text" id="cat_title" name="cat_title" class="form-control" value="<?= @$category[0]->cat_title; ?>" placeholder="Enter ..." required>
                            <!-- <input type="hidden" name="action" vale="<?= (@$category[0]->cat_title!='')?'edit':'add'; ?>"> -->
                          </div>
                        </div>
                      </div>
                  </div>
                <div class="card-footer text-right">
                    <button type="submit" id="cat-form-btn" class="btn btn-outline-success px-5 mr-2" style="height: 45px;">SUBMIT</button>
                    <a href="javascript:history.go(-1);" class="btn btn-outline-secondary px-5" style="padding: 12px 0;">CANCEL</a>
                </div>
              </form>

            </div>
           </section>
         
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
  </div>
      
<?php $this->load->view('template/footer'); ?>
<script src="<?= base_url(); ?>assets/admin/jquery.validate.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    $("form").attr('autocomplete','off');
    $("input").attr('autocomplete','off');
});
</script>

<script type="text/javascript">
$(document).ready(function() {  

    $("#cat-frm").attr('autocomplete','off');

    $("#cat-frm").validate({

        errorElement: 'span',

        errorClass: 'invalid-feedback',

        successClass: 'is-valid',

        rules: {

            cat_title: {

                required: true,

            },

        },

        messages: {


            cat_title: {

                required: "Please enter category name",

            },


        },

        errorPlacement: function (error, element) {

            element.closest('.form-group').append(error);

        },

        highlight: function (element, errorClass, validClass) {

            $(element).removeClass('is-valid').addClass('is-invalid');

        },

        unhighlight: function (element, errorClass, validClass) {

            $(element).removeClass('is-invalid').addClass('is-valid');

        },

        submitHandler: function(form) 
        {
            $('#cat-form-btn').prop('disabled',true);
            form.submit();
        }

    });
});
  
</script>



</body>
</html>
