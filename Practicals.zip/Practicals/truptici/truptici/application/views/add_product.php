<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Product</title>
  
<?php $this->load->view('template/header'); ?>  
  <!-- summernote -->
  <link rel="stylesheet" href="<?= base_url(); ?>assets/admin/plugins/summernote/summernote-bs4.css">
<?php $this->load->view('template/sidebar'); ?>

<style type="text/css">
.help-block.text-danger {
    font-size: 14px;
}
</style>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header py-1">
      <div class="container-fluid">
        <div class="row mb-2">
          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- Left col -->
           <section class="col-md-8 offset-2">
             <div class="card card-warning card-outline">
              <div class="card-header">
                <h3 class="card-title">
                  Product
                </h3>
              </div>
              <!-- /.card-header -->
            <form role="form" method="post" action="" id="prod-frm" name="prod-frm" enctype="multipart/form-data">
                  <div class="card-body">
                     <div class="row">
                        <div class="col-md-8">
                          <div class="form-group">
                            <label>Product Title <span class="text-maroon">*</span></label>
                            <input type="text" id="product_title" name="product_title" class="form-control" value="<?= @$info[0]->product_title; ?>" placeholder="Enter ..." required>
                            
                          </div>
                          
                          <div class="form-group">
                            <?php $cat=explode('|*|',@$info[0]->categories); ?>
                            <label>Select Categories <span class="text-maroon">*</span></label>
                            <select class="custom-select" id="categories" name="categories[]" multiple>
                                <option value="">Select Categories</option>
                                <?php if(count($categories)>0){
                                  foreach($categories as $ckey => $category) { ?>
                                  <option value="<?= $category->cat_id; ?>" <?= (in_array($category->cat_id, $cat))?'selected':''; ?>><?= $category->cat_title; ?></option>
                                  <?php }
                                  } ?>
                            </select>
                            
                          </div>
                          
                          
                          <div class="form-group">
                              <label for="featured-banner">Featured Image ( <code>1180x400px</code>)</label>
                              <div class="input-group">
                                <div class="custom-file">
                                  <input type="file" name="featured_img" class="custom-file-input" id="featured-banner" data-imageWidth='' data-imageHeight='' accept="image/*">  
                                  <label class="custom-file-label" for="featured-banner">Choose file</label>
                                </div>
                              </div>
                              <?php if(@$info[0]->featured_image!=''){ ?>
                                <p><a href="<?= base_url(); ?>assets/uploads/featured_image/<?= @$info[0]->product_id; ?>/<?= @$info[0]->featured_image; ?>" target="_blank"><?= @$info[0]->featured_image; ?></a></p>
                                <?php } ?>
                            </div>
                              <div class="form-group">
                                <label for="gallary_img">Gallary (Choose multiple)</label>
                                <div class="input-group">
                                  <div class="custom-file">
                                    <input type="file" name="gallary_img[]" class="custom-file-input" id="gallary_img" accept="image/*" multiple>  
                                    <label class="custom-file-label" for="gallary_img">Choose file</label>
                                  </div>
                                </div> <p>
                                <?php if(@$info[0]->product_id!='' && count($gallary)>0){
                                  foreach($gallary as $gkl => $gal) { ?>
                                 <a href="<?= base_url(); ?>assets/uploads/gallary/<?= @$gal->prod_id; ?>/<?= @$gal->image_name; ?>" target="_blank"><?= @$gal->image_name; ?></a><?= (count($gallary)!=$gkl+1)?'<br> ':'';?>
                                  <?php }
                                  } ?></p>
                            </div>
                            <div class="form-group">
                            <label>Product Description </label>
                                 <textarea class="textarea" name="product_description" placeholder="Place some text here"
                              style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?= @$info[0]->product_description; ?></textarea>
                          </div>
                        </div>
                      </div>
                  </div>
                <div class="card-footer text-right">
                    <button type="submit" id="cat-form-btn" class="btn btn-outline-success px-5 mr-2" style="height: 45px;">SUBMIT</button>
                    <a href="javascript:history.go(-1);" class="btn btn-outline-secondary px-5" style="padding: 12px 0;">CANCEL</a>
                </div>
              </form>

            </div>
           </section>
         
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
  </div>
      
<?php $this->load->view('template/footer'); ?>
<script src="<?= base_url(); ?>assets/admin/jquery.validate.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    $("form").attr('autocomplete','off');
    $("input").attr('autocomplete','off');
});
</script>

<script type="text/javascript">
$(document).ready(function() { 
$('body').on('change', 'input[type="file"]', function(e){
  var fileName = e.target.files[0].name;
  $(this).next('.custom-file-label').html(fileName);
}); 
    $.validator.addMethod('dimention', function(value, element, param) {
        if(element.files.length == 0){
            return true;
        }
        var width = $(element).data('imageWidth');
        var height = $(element).data('imageHeight');
        if(width == param[0] && height == param[1]){
            return true;
        }else{
            return false;
        }
    },'Please upload an image with 1180 x 400 pixels dimension');

    $('#featured-banner').change(function() {
        $('#featured-banner').removeData('imageWidth');
        $('#featured-banner').removeData('imageHeight');
        var file = this.files[0];
        var tmpImg = new Image();
        tmpImg.src=window.URL.createObjectURL( file ); 
        tmpImg.onload = function() {
            width = tmpImg.naturalWidth,
            height = tmpImg.naturalHeight;
            $('#featured-banner').data('imageWidth', width);
            $('#featured-banner').data('imageHeight', height);
        }
    });
    $("#prod-frm").attr('autocomplete','off');

    $("#prod-frm").validate({

        errorElement: 'span',

        errorClass: 'invalid-feedback',

        successClass: 'is-valid',

        rules: {

            product_title: {

                required: true,

            },
            "categories[]": {

                required: true,

            },
             featured_img: {
                   //dimention:[1180,400],
                },
        },

        messages: {


            product_title: {

                required: "Please enter product name",

            },
          "categories[]": {

                required: "Please select category",

            },


        },

        errorPlacement: function (error, element) {

            element.closest('.form-group').append(error);

        },

        highlight: function (element, errorClass, validClass) {

            $(element).removeClass('is-valid').addClass('is-invalid');

        },

        unhighlight: function (element, errorClass, validClass) {

            $(element).removeClass('is-invalid').addClass('is-valid');

        },

        submitHandler: function(form) 
        {
            $('#cat-form-btn').prop('disabled',true);
            form.submit();
        }

    });
});
  
</script>
<!-- Summernote -->
<script src="<?= base_url(); ?>assets/admin/plugins/summernote/summernote-bs4.min.js"></script>
<script>
  $(function () {
    // Summernote
    $('.textarea').summernote()
  })
</script>


</body>
</html>
