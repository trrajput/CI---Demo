<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Login</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <meta name="robots" content="noindex" />
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?= base_url(); ?>assets/admin/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <link rel="stylesheet" href="<?= base_url(); ?>assets/admin/dist/css/adminlte.css">

<style type="text/css">
  .btn-block:active {
    background-color: #a97415 !important;
    border-color: #a97415 !important;
  }
</style>

</head>
<body class="hold-transition login-page">
<div class="login-box">
  
  <!-- /.login-logo -->
  <div class="row">

    <div class="col-12">

      <div id="flash_msg" class="">

          
        </div>

      </div>   

    </div>
  <div class="card">
    <div class="card-body login-card-body shadow rounded">
      <p class="login-box-msg font-weight-bold">LOGIN TO ADMIN PANEL</p>

      <form action="" method="post">
        <div id="flash_msg"></div>
        <div class="input-group mb-3">
          <input type="email" name="email" class="form-control rounded-0 shadow-none h6 mb-0 <?= (form_error('email'))?'is-invalid':''; ?>" id="email" placeholder="Enter Email" value="<?php if(isset($_GET['mail'])){ echo $_GET['mail']; }else{ echo set_value('email'); } ?>" required>
                          
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
          <?php if(form_error('email')){  
              echo '<span for="email" class="invalid-feedback">'.form_error('email').'</span>'; 
            } ?>
        </div>
        <div class="input-group mb-3">
          <input type="password" name="password" class="form-control rounded-0 shadow-none h6 mb-0 <?= (form_error('password'))?'is-invalid':''; ?>" id="password" placeholder="Enter Password" required>
                           
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
           <?php if(form_error('password')){  
                            echo '<span for="password" class="invalid-feedback">'.form_error('password').'</span>'; 
                          } ?>
        </div>
        <div class="row">
          <!-- /.col -->
          <div class="col-12">
            <button type="submit" class="btn btn-primary btn-block" style="padding: 10px;">LOGIN</button>
          </div>
          <!-- /.col -->
        </div>
      </form>

      <p class="my-3">
        <a href="<?= base_url(); ?>the-triangles-admin/forgot-password"></a>
      </p>
    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="<?= base_url(); ?>assets/admin/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?= base_url(); ?>assets/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url(); ?>assets/admin/dist/js/adminlte.min.js"></script>

<script type="text/javascript">
        function admin_path () {
            return '<?=admin_path()?>';
        }

         function base_path(){
            return '<?=base_path()?>';   
        }


        function success_msg_box (msg) {
            var html = '<div class="alert alert-success alert-dismissable"> \n\
                            <i class="fa fa-check"></i> \n\
                            <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button> \n\
                            '+msg+' \n\
                        </div>';
            return html;
        }

        function error_msg_box(msg)
        {
            var html = '<div class="alert alert-danger alert-dismissable"> \n\
                            <i class="fa fa-ban"></i> \n\
                            <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button> \n\
                            '+msg+' \n\
                        </div>';
            return html;
        }

        function remove_msg_box()
        {
            setInterval(function(){ $('#flash_msg').html(''); }, 10000);
        }

         <?php if($this->session->flashdata('success')) { ?>
              $('#flash_msg').html(success_msg_box("<?php echo $this->session->flashdata('success'); ?>"));
              remove_msg_box();
          <?php 
          }else if($this->session->flashdata('error'))
          { ?>
              $('#flash_msg').html(error_msg_box("<?php echo $this->session->flashdata('error'); ?>"));
              remove_msg_box();
          <?php 
           } else { ?>
              $('#flash_msg').html('');
          <?php } ?>
    </script>


</body>
</html>
