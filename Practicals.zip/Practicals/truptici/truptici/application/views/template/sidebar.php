  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
      
      <!-- Notifications Dropdown Menu -->
      <li class="nav-item">
        <a class="nav-link"  href="<?= base_url(); ?>welcome/logout">
          <i class="fas fa-power-off"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar elevation-4 sidebar-light-gray">
    <!-- Brand Logo -->
    
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex justify-content-center">
        <div class="image">
          <img src="<?= base_url(); ?>assets/images/asdas-min.png" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="javascript:void(0);" class="d-block">Admin</a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column nav-flat" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview">
            <a href="<?= base_url(); ?>welcome/dashboard" class="nav-link <?= get_active_tab_main('dashboard'); ?>">
              <i class="nav-icon fas fa-users"></i>
              <p>
                User List
              </p>
            </a>
          </li>
         
          <li class="nav-item has-treeview">
            <a href="<?= base_url(); ?>welcome/categories" class="nav-link <?= get_active_tab_main('categories'); ?><?= get_active_tab_main('add_category'); ?><?= get_active_tab_main('edit_category'); ?>">
              <i class="fas fa-list-ul nav-icon"></i>
              <p>
                Categories
              </p>
            </a>
          </li>
         
          <li class="nav-item has-treeview">
            <a href="<?= base_url(); ?>welcome/products" class="nav-link <?= get_active_tab_main('products'); ?><?= get_active_tab_main('add_product'); ?><?= get_active_tab_main('edit_product'); ?><?= get_active_tab_main('view_product'); ?>">
              <i class="fas fa-list-ul nav-icon"></i>
              <p>
                Products
              </p>
            </a>
          </li>
        
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>