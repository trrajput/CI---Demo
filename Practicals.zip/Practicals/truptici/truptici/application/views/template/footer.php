  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>&copy; <?= date('Y'); ?></strong>
    All rights reserved.
  </footer>

</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?= base_url(); ?>assets/admin/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?= base_url(); ?>assets/admin/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<!-- Bootstrap 4 -->
<script src="<?= base_url(); ?>assets/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- AdminLTE App -->
<script src="<?= base_url(); ?>assets/admin/dist/js/adminlte.min.js"></script>

<script> 
 function admin_path () {
            return '<?=admin_path()?>';
        }

         function base_path(){
            return '<?=base_path()?>';   
        }


        function success_msg_box (msg) {
            var html = '<div class="alert alert-success alert-dismissable"> \n\
                            <i class="fa fa-check"></i> \n\
                            <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button> \n\
                            '+msg+' \n\
                        </div>';
            return html;
        }

        function error_msg_box(msg)
        {
            var html = '<div class="alert alert-danger alert-dismissable"> \n\
                            <i class="fa fa-ban"></i> \n\
                            <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button> \n\
                            '+msg+' \n\
                        </div>';
            return html;
        }

        function remove_msg_box()
        {
            setInterval(function(){ $('#flash_msg').html(''); }, 10000);
        }

         <?php if($this->session->flashdata('success')) { ?>
              $('#flash_msg').html(success_msg_box("<?php echo $this->session->flashdata('success'); ?>"));
              remove_msg_box();
          <?php 
          }else if($this->session->flashdata('error'))
          { ?>
              $('#flash_msg').html(error_msg_box("<?php echo $this->session->flashdata('error'); ?>"));
              remove_msg_box();
          <?php 
           } else { ?>
              $('#flash_msg').html('');
          <?php } ?>
</script>
<script type="text/javascript">
	var base_path = '<?= base_url(); ?>';
	$(".loader").hide();
	$(function () {
	    $('[data-toggle="tooltip"]').tooltip()
	});
</script>