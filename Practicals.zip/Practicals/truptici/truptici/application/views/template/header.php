<?php if(!$this->admin_session['admin_id']){
    redirect(base_url());
}
?><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex" />
  
<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">

<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">

<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

<link rel="stylesheet" href="<?= base_url(); ?>assets/admin/dist/css/adminlte.css">

<style type="text/css">
.bulk-action a{
	margin-right: 5px;
}
</style>

</head>

<body class="hold-transition sidebar-mini layout-fixed sidebar-collapse">

<div class="loader" style="display: none;">
	<div style="background: #fff;z-index: 9999;display: grid;width: 100%;position: fixed;height: 100%;">
		<img src="<?= base_url(); ?>assets/images/loader.gif" style="z-index: 9999;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);">
	</div>
</div>
<div class="loader2" style="display: none;">
	<div style="background: #ffffff9c;z-index: 9999;display: grid;width: 100%;position: fixed;height: 100%;">
		<img src="<?= base_url(); ?>assets/images/loader.gif" style="z-index: 9999;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);">
	</div>
</div>

<div class="wrapper">