<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Product Details</title>

<?php $this->load->view('template/header'); ?>  

<?php $this->load->view('template/sidebar'); ?>
<style type="text/css">
  .user-block img {
      height: 100px;
      width: 100px;
  }
  .post .user-block {
    width: 35%;
  }
  .wb-you-learn ul li {
      list-style-image: url('<?= base_url(); ?>assets/images/arrow.png');
  }
  .post {
    border: 0;
  }

</style>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header py-1">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?= base_url(); ?>the-triangles-admin/sessions/sessions-list/upcoming">Products</a></li>
              <li class="breadcrumb-item active">Product Details</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card card-warning card-outline">
        <div class="card-header">
          <h3 class="card-title mt-1">Product Details</h3>
          <div class="float-right">
            
            <a href="<?= base_url(); ?>welcome/edit-product/<?= @$info[0]->p_slug; ?>" data-toggle="tooltip" data-placement="top" title="Update" class="btn btn-outline-success btn-sm">EDIT</a>
          </div>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-12 col-md-12 col-lg-8 order-2 order-md-1">
              <div class="row">

                <div class="col-12 col-sm-3">
                  <div class="info-box bg-light">
                    <div class="info-box-content">
                      <span class="info-box-text text-center text-dark">CREATION TIME</span>
                      <span class="info-box-number text-center text-dark mb-0"><?= date('d-m-Y',strtotime(@$info[0]->created_at)); ?></span>
                    </div>
                  </div>
                </div>

               
              </div>
              <div class="row">
                  <div class="col-12">
                    <div class="mb-3">
                      <img src="<?= base_url(); ?>assets/uploads/featured_image/<?= $info[0]->product_id; ?>/<?= $info[0]->featured_image; ?>" style="width: 100%;">
                    </div>
                  </div>
              </div>
              
              <div class="row">
                  <div class="col-12">
                    <h5 class="mb-2 font-weight-bold text-success">Product Title</h5>
                          <p class=""><?= $info[0]->product_title; ?></p>
                  </div>
              </div>
             

              <div class="row">
                  <div class="col-12">
                    <h5 class="mb-2 font-weight-bold text-success">Product Description</h5>
                          <p class="mx-4 text-justify"><?= $info[0]->product_description; ?></p>
                  </div>
              </div>
              <div class="row">
                  <div class="col-12">
                    <h5 class="mb-2 font-weight-bold text-success">Categories</h5>
                          <p class="text-justify"><?= $cat; ?></p>
                  </div>
              </div>
              
       
              <div class="row">
                <div class="col-12">
                  <h5 class="mb-2 font-weight-bold text-success">Gallary</h5>
                  <div class="post clearfix">
                  <div class="user-block">
                  <?php

                  foreach($info as $key => $ivalue) {

                    if($ivalue->image_name!=''){ ?>
                    
                            <img class="mr-1" src="<?= base_url(); ?>assets/uploads/gallary/<?= $ivalue->product_id; ?>/<?= @$ivalue->image_name ;?>" alt="image">
                        
                    <?php } } ?>
                    </div>
                          
                  </div>
                </div>
              </div>
        
           

            </div>
           
            </div>
          </div>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->

    </section>
  </div>

<?php $this->load->view('template/footer'); ?>

<script type="text/javascript">
 $('body').on('click', '.change_status', function() {  
        var id = '<?= @$session_details[0]->session_id; ?>';
        var tblename = 'sessions'; 
        if($(this).text()=='ACTIVE') {
          var status = 'Inactive';
        }else {
          var status = 'Active';
        }
        $.ajax({
              url:base_path+'the-triangles-admin/index/change_status',
              type:"POST",
              data:{'session_id': id,'status':status,'tblename':tblename},
              success:function(result) {   
                 if(result=='success') {
                  location.reload();
                 }
              },
        });
    });

</script>

</body>
</html>
